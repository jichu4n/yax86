// Stand-ins for the handful of Pico SDK calls the harness makes, so that the
// same main.c can be built for the host.
//
// This exists so the harness logic - blob loading, the run loop, the sentinel
// check and the arithmetic behind every printed figure - can be checked
// against the desktop harness's known numbers without a board attached. It is
// a test scaffold, not a port: nothing here belongs in a firmware build, which
// is why main.c includes it only under YAX86_PICO_HOST.

#ifndef YAX86_PICO_HOST_STUBS_H
#define YAX86_PICO_HOST_STUBS_H

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <time.h>

enum {
  kNanosecondsPerMicrosecond = 1000,
  kMicrosecondsPerMillisecond = 1000,
  // What getchar_timeout_us() returns when nothing arrived. The host build
  // never waits for input, so this is all it ever returns.
  kHostTimeout = -1,
};

// The SDK's clock identifiers, of which the harness names only the system
// clock. Nothing on the host has one, so a plausible RP2040 default is
// reported and the header says which build it came from anyway.
typedef enum HostClockIndex {
  clk_sys = 0,
} HostClockIndex;

enum {
  kHostSystemClockHz = 125000000,
};

static inline uint64_t time_us_64(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (uint64_t)ts.tv_sec * 1000000u +
         (uint64_t)ts.tv_nsec / kNanosecondsPerMicrosecond;
}

static inline void stdio_init_all(void) {
  // Line buffering would hold a result back until the next newline, and this
  // build's whole purpose is to be compared line by line against another's.
  setvbuf(stdout, NULL, _IOLBF, 0);
}

// The host's terminal is attached as soon as the process starts.
static inline bool stdio_usb_connected(void) { return true; }

// Never offered a choice, so the host build always runs every workload.
static inline int getchar_timeout_us(uint32_t timeout_us) {
  (void)timeout_us;
  return kHostTimeout;
}

static inline void sleep_ms(uint32_t ms) {
  struct timespec ts = {
      .tv_sec = (time_t)(ms / kMicrosecondsPerMillisecond),
      .tv_nsec = (long)(ms % kMicrosecondsPerMillisecond) * 1000000L,
  };
  nanosleep(&ts, NULL);
}

static inline uint32_t clock_get_hz(HostClockIndex clock_index) {
  (void)clock_index;
  return kHostSystemClockHz;
}

#endif  // YAX86_PICO_HOST_STUBS_H
