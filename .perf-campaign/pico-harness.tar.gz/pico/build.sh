#!/bin/bash
# Builds the Pico benchmark firmware at every optimization level and reports
# what each one costs in flash and SRAM.
#
# The three variants are the experiment: the RP2040 runs code from flash
# through a 16KB XIP cache, so the level that wins on a desktop is not
# necessarily the one that wins here, and the only way to find out is to flash
# all three and compare. Name levels on the command line to build a subset.
#
#   ./build.sh                 # Os, O2 and O3
#   ./build.sh O3              # just one
#   ./build.sh --host          # also build the host check, see below
#
# Environment:
#   YAX86_CORE_ROOT   Checkout whose core/ is compiled in, for A/B'ing two core
#                     revisions against the same harness. Defaults to this one.
#   YAX86_PICO_GUEST_RAM_KB   Guest RAM, 128 or 192. Defaults to 128.
#   PICO_SDK_PATH     Where the Pico SDK lives.

set -e
cd "$(dirname "${BASH_SOURCE[0]}")"

BUILD_ROOT="$(cd .. && pwd)/build-pico"
CORE_ROOT="$(cd "${YAX86_CORE_ROOT:-..}" && pwd)"
GUEST_RAM_KB="${YAX86_PICO_GUEST_RAM_KB:-128}"
BUILD_HOST=0
OPT_LEVELS=()

for arg in "$@"; do
    case "$arg" in
        --host) BUILD_HOST=1 ;;
        Os|O2|O3) OPT_LEVELS+=("$arg") ;;
        *)
            echo "Usage: build.sh [--host] [Os] [O2] [O3]" >&2
            exit 1
            ;;
    esac
done
if [ ${#OPT_LEVELS[@]} -eq 0 ]; then
    OPT_LEVELS=(Os O2 O3)
fi

if [ -z "${PICO_SDK_PATH:-}" ]; then
    echo "!! PICO_SDK_PATH is not set" >&2
    exit 1
fi

for opt in "${OPT_LEVELS[@]}"; do
    echo "==> Building -$opt with ${GUEST_RAM_KB}K guest RAM from $CORE_ROOT"
    cmake -S . -B "$BUILD_ROOT/$opt" \
        -DYAX86_PICO_OPT="$opt" \
        -DYAX86_PICO_GUEST_RAM_KB="$GUEST_RAM_KB" \
        -DYAX86_CORE_ROOT="$CORE_ROOT" >/dev/null
    cmake --build "$BUILD_ROOT/$opt" -j"$(nproc)"
done

# -----------------------------------------------------------------------------
# Host check
# -----------------------------------------------------------------------------
# The same harness source compiled for the host, so that the run loop, the
# sentinel check and the arithmetic behind every printed figure can be checked
# against the desktop harness's known numbers without a board attached.
if [ "$BUILD_HOST" = 1 ]; then
    echo "==> Building host check"
    mkdir -p "$BUILD_ROOT/host/workloads"
    # The DOS floppy's C array is generated rather than committed, so this
    # build has to make its own copy the way the CMake build does.
    ../core/tools/generate-rom-data-files.js \
        "../resources/MS-DOS 3.30/DISK01.IMG" \
        "$BUILD_ROOT/host/workloads/dos_floppy_data" DOSFloppyData
    cc -O2 -std=c99 -D_POSIX_C_SOURCE=200809L -Wall -Wextra \
        -DYAX86_PICO_HOST -DYAX86_PICO_GUEST_RAM_KB="$GUEST_RAM_KB" \
        -DYAX86_PICO_OPT='"-O2 (host)"' \
        -I"$CORE_ROOT" -Isrc -I"$BUILD_ROOT/host" \
        -o "$BUILD_ROOT/host/yax86_pico_bench_host" \
        src/main.c src/workloads/*.c "$BUILD_ROOT/host/workloads/"*.c \
        "$CORE_ROOT/core/yax86_core.c"
    echo "    $BUILD_ROOT/host/yax86_pico_bench_host"
fi

# -----------------------------------------------------------------------------
# Summary
# -----------------------------------------------------------------------------
# Three figures per variant. Flash and SRAM are what has to fit on the board,
# taken from the program headers so that they agree with what the linker
# printed during the link. The core's own .text is the one to line up against
# the desktop measurements, since it leaves out the SDK and the harness.
#
# Flash is what is loaded from it, which includes the initializers for
# everything in .data; SRAM is what is reserved in it, which includes .bss and
# the heap but not the stack, which lives in a scratch bank of its own.
segment_bytes() {
    arm-none-eabi-readelf -lW "$1" | awk -v want="$2" '
        $1 == "LOAD" {
            file_size = strtonum($5);
            mem_size = strtonum($6);
            virt = strtonum($3);
            phys = strtonum($4);
            if (want == "flash" && phys < 0x20000000) total += file_size;
            if (want == "ram" && virt >= 0x20000000 && virt < 0x20040000) {
                total += mem_size;
            }
        }
        END { print total + 0 }'
}

echo
printf '%-6s %10s %10s %10s  %s\n' opt flash sram core_text uf2
for opt in "${OPT_LEVELS[@]}"; do
    build="$BUILD_ROOT/$opt"
    elf="$build/yax86_pico_bench.elf"
    # Spelled out rather than searched for: CMake names an object after the
    # absolute path of its source, so a build directory reused across two
    # YAX86_CORE_ROOTs holds one object per core, and a search would report
    # whichever it happened to find first.
    core_obj="$build/CMakeFiles/yax86_pico_bench.dir/${CORE_ROOT#/}/core/yax86_core.c.o"
    core_text="$(arm-none-eabi-size "$core_obj" | tail -1 | awk '{print $1}')"
    printf '%-6s %10s %10s %10s  %s\n' \
        "-$opt" "$(segment_bytes "$elf" flash)" "$(segment_bytes "$elf" ram)" \
        "$core_text" "$build/yax86_pico_bench.uf2"
done
